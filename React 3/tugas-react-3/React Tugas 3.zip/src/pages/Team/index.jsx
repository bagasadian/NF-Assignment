import Footer from "../../components/shared/Footer";
import Header from "../../components/shared/Header";
import Team from "../../components/shared/Team";

export default function Teams(){
    return(
        <>
        <Header/>
        <Team/>
        <Footer/>
        </>
    )
}